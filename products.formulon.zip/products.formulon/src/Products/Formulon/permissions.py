##############################################################################
#
# Copyright (c) 2003 gocept gmbh & co. kg. All rights reserved.
#
# See also LICENSE.txt
#
##############################################################################
"""String constants for formulon permissions

$Id$"""

READFIELD = 'Formulon: Read access to field'
WRITEFIELD = 'Formulon: Write access to field'

